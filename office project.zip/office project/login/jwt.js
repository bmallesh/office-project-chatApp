var jwt = require("jwt-simple");
module.exports = {
    "getToken":function (obj,password) {
        return jwt.encode(obj,password);
    }
};