var express=require("express");
var connection=require("./connection");
var app=express();
app.use(express.static(__dirname+"/../insert"));
var conn=connection.getConnection();
conn.connect();
app.get("/insert",function (req,res) {
   var uname=req.param("uname");
   var Gmail=req.param("gmail");
   var phoneNo=req.param("phoneno");
   var upwd=req.param("password");
   var sql="insert into login values('"+uname+"',"+"'"+Gmail+"'"+","+phoneNo+","+"'"+upwd+"'"+")";
    conn.query(sql,function (err) {
        if (err){ 
            console.log("row is not ninserted");
        }else{
            res.send(" successes !");
        }

    });
});
app.listen(8020);
console.log("server listening port no :8020");